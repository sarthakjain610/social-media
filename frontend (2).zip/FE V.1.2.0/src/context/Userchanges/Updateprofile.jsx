import React, { useState } from 'react';

export default function Profile() {
  const [user, setUser] = useState({});
  const [updatedUser, setUpdatedUser] = useState({}); // To store updated user data
  const [isEditing, setIsEditing] = useState(false); // To control the edit mode

  const handleUpdateProfile = () => {
    setIsEditing(true);
  };

  const handleSaveProfile = async () => {
    try {
      // Make a PUT request to update the user's profile
      await axios.put(`http://localhost:8800/api/user/${userId._id}`, updatedUser);
      setIsEditing(false);
      // Fetch the user's updated data after the profile is updated
      fetchUser();
    } catch (error) {
      console.error("Error updating profile:", error);
      // Handle errors or display an error message
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
  };

  return (
    <>
      <Topbar />
      <div className="profile">
        <Sidebar />
        <div className="profileRight">
          <div className="profileRightTop">
            {/* ... Other profile content ... */}
            <div className="profileInfo">
              <h4 className="profileInfoName">
                {isEditing ? (
                  <input
                    type="text"
                    value={updatedUser.Username}
                    onChange={(e) =>
                      setUpdatedUser({ ...updatedUser, Username: e.target.value })
                    }
                  />
                ) : (
                  user.Username
                )}
              </h4>
              <span className="profileInfoDesc">{user.desc}</span>
              {isEditing ? (
                <div>
                  <button onClick={handleSaveProfile}>Save</button>
                  <button onClick={handleCancelEdit}>Cancel</button>
                </div>
              ) : (
                <button onClick={handleUpdateProfile}>Update Profile</button>
              )}
            </div>
          </div>
          <div className="profileRightBottom">
            <Feed Username={"null"} />
          </div>
        </div>
      </div>
    </>
  );
}
