const router = require("express").Router()
const bcrypt = require('bcrypt')

const User = require("../models/User")


router.post("/register", async (req,res)=>{
    // const user =   new User({
    //     Username:"shantanuH",
    //     email:"shantanuH@xyz",
    //     password:"147852369H"
    // })
    
    try{
        // generation of password
        const salt = await bcrypt.genSalt(10)
        const hashPass = await bcrypt.hash(req.body.password,salt)
        // create new user
        const user = new User({
            Username : req.body.Username,
            email : req.body.email,
            password : hashPass
        })
        // saving user and returning response
        const usr = await user.save()
        res.status(200).json(usr)
    }catch(err){
        res.status(500).json(err)
    }
    //  user.save()
    // res.send("ok")
})

// user login

router.post("/login", async (req,res)=>{
    try{
        const e = req.body.email
        const login_user = await User.findOne({email : e})
        !login_user && res.status(404).json("user not found")
   
        const Pass = await bcrypt.compare(req.body.password,login_user.password)
        !Pass && res.status(400).json("wrong password")

        res.status(200).json(login_user)
    }catch(err){
        res.status(500).json(err)
    }
})


// router.get("/",(req,res)=>{
//     res.send("hello")
// })

module.exports = router