const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const helmet = require("helmet");
const morgan = require("morgan");
// const cors = require('cors');
const multer = require("multer")
const path = require("path");

const userRoute = require("./routes/users");
const authRoute = require("./routes/auth");
const postRoute = require("./routes/posts");

dotenv.config()
const app = express()
app.use(express.urlencoded({ extended: true }));


mongoose.connect(process.env.MONGO_URL,{useNewUrlParser:true})
  .then(() => console.log('Connected to the database!'));

  app.use((req, res, next) => {
    res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
    next();
});

const cors = require('cors');
app.use(cors());


  
app.use(express.json())
app.use(helmet())
app.use(morgan("common"))

// app.use(cors());

// app.use("/images", express.static(path.join(__dirname, "images")));
app.use("/images", express.static(path.join(__dirname, "images")));



// const storage =multer.diskStorage({            //change 7/4/24
//   destination:(req,file,cb)=>{
//     cb(null,"images")
//   },filename:(req,file,cb)=>{
//       cb(null,file.originalname);
//   }
// });

const storage = multer.diskStorage({              //change 7/4/24
  destination: (req, file, cb) => {
    cb(null, "images");
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const fileExtension = path.extname(file.originalname);
    const newFilename = `${uniqueSuffix}${fileExtension}`;
    cb(null, newFilename);
  }
});


const upload = multer({storage});
app.post("/api/upload/",upload.single("file"),(req,res)=>{

  try{
    return res.status(200).json("file uploaded successfully")
  }catch(err){
    console.log(err)
  }
})
app.use("/api/user",userRoute)
app.use("/api/auth",authRoute)
app.use("/api/posts",postRoute)




app.listen(8800,()=>{
    console.log("server running")
})